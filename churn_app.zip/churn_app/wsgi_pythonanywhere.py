# Paste the contents of this file into your PythonAnywhere WSGI file
# (Web tab -> "WSGI configuration file"), replacing everything in it.
# Change YOUR_USERNAME to your PythonAnywhere username.
import sys

project_home = "/home/YOUR_USERNAME/churn_app"
if project_home not in sys.path:
    sys.path.insert(0, project_home)

from app import app as application   # PythonAnywhere looks for the name "application"
