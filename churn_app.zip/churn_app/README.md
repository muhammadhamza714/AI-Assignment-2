# Churn Check - Customer Churn Prediction (Flask)

Web app for Assignment 2. It uses the **Random Forest** model selected in Assignment 1.

```
churn_app/
  app.py                  Flask backend: routes, validation, preprocessing, prediction
  train_model.py          Re-creates Assignment 1 training and saves the artifacts
  model.joblib            Saved Random Forest model
  scaler.joblib           Saved StandardScaler (numeric columns)
  model_meta.json         Feature column order, numeric columns, metrics
  requirements.txt
  wsgi_pythonanywhere.py  WSGI file for deployment
  DEPLOYMENT.md           Step-by-step PythonAnywhere guide
  data/                   Telco dataset used by train_model.py
  templates/index.html    Page (form + result)
  static/style.css        Styling
  static/app.js           Small helpers (example customers, linked fields)
  tests/test_app.py       Automated checks
```
