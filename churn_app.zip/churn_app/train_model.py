"""
train_model.py  -  Re-creates the Assignment 1 pipeline and SAVES the artifacts
needed by the Flask app.

Run once:  python train_model.py
Creates :  model.joblib, scaler.joblib, model_meta.json
"""
import json
import os
import warnings

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

warnings.filterwarnings("ignore")
RANDOM_STATE = 42
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "data", "WA_Fn-UseC_-Telco-Customer-Churn.xlsx")

# ---------------------------------------------------------------- 1. load
df = pd.read_excel(DATA_FILE)

# ---------------------------------------------------------------- 2. clean (same as Assignment 1)
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce").fillna(0)
df = df.drop_duplicates().drop(columns=["customerID"])

# ---------------------------------------------------------------- 3. features (same as Assignment 1)
data = df.copy()
data["Churn"] = data["Churn"].map({"No": 0, "Yes": 1})
data["AvgMonthlySpend"] = data["TotalCharges"] / (data["tenure"] + 1)
data_encoded = pd.get_dummies(data, drop_first=True).astype(float)

X = data_encoded.drop("Churn", axis=1)
y = data_encoded["Churn"].astype(int)

# ---------------------------------------------------------------- 4. split + scale
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y)

num_cols = ["tenure", "MonthlyCharges", "TotalCharges", "AvgMonthlySpend"]
scaler = StandardScaler()
X_train_s, X_test_s = X_train.copy(), X_test.copy()
X_train_s[num_cols] = scaler.fit_transform(X_train[num_cols])
X_test_s[num_cols] = scaler.transform(X_test[num_cols])

# ---------------------------------------------------------------- 5. models (same settings as Assignment 1)
models = {
    "Logistic Regression": (LogisticRegression(max_iter=1000, class_weight="balanced",
                                               random_state=RANDOM_STATE), True),
    "Decision Tree": (DecisionTreeClassifier(max_depth=5, class_weight="balanced",
                                             random_state=RANDOM_STATE), False),
    "Random Forest": (RandomForestClassifier(n_estimators=300, max_depth=8,
                                             class_weight="balanced",
                                             random_state=RANDOM_STATE, n_jobs=-1), False),
}

results = {}
for name, (model, needs_scaling) in models.items():
    model.fit(X_train_s if needs_scaling else X_train, y_train)
    Xte = X_test_s if needs_scaling else X_test
    pred, proba = model.predict(Xte), model.predict_proba(Xte)[:, 1]
    results[name] = {
        "accuracy": round(accuracy_score(y_test, pred), 3),
        "precision": round(precision_score(y_test, pred), 3),
        "recall": round(recall_score(y_test, pred), 3),
        "f1": round(f1_score(y_test, pred), 3),
        "roc_auc": round(roc_auc_score(y_test, proba), 3),
    }

print(pd.DataFrame(results).T)

# ---------------------------------------------------------------- 6. best model (by F1, as in Assignment 1)
best_name = max(results, key=lambda n: results[n]["f1"])
best_model, best_scaled = models[best_name]
print("\nBest model by F1-Score:", best_name)

# ---------------------------------------------------------------- 7. save artifacts
joblib.dump(best_model, os.path.join(BASE_DIR, "model.joblib"))
joblib.dump(scaler, os.path.join(BASE_DIR, "scaler.joblib"))
meta = {
    "model_name": best_name,
    "needs_scaling": best_scaled,
    "num_cols": num_cols,
    "feature_columns": list(X.columns),   # exact column ORDER used in training
    "metrics": results[best_name],
    "all_metrics": results,
}
with open(os.path.join(BASE_DIR, "model_meta.json"), "w") as f:
    json.dump(meta, f, indent=2)
print("Saved: model.joblib, scaler.joblib, model_meta.json "
      f"({len(X.columns)} features)")
