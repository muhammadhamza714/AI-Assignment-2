/* Churn Check - small bits of front-end behaviour.
   The server re-checks everything, so this file only makes the form nicer to use. */
(function () {
  "use strict";

  var form = document.getElementById("churn-form");

  /* ---------- 1. light up the result meter ---------- */
  var meter = document.querySelector(".meter[data-lit]");
  if (meter) {
    var lit = parseInt(meter.getAttribute("data-lit"), 10) || 0;
    meter.querySelectorAll(".bar").forEach(function (bar, i) {
      if (i < lit) bar.classList.add("on");
    });
    requestAnimationFrame(function () { meter.classList.add("play"); });
  }

  /* ---------- helpers ---------- */
  function setRadio(name, value) {
    var input = form.querySelector('input[name="' + name + '"][value="' + value + '"]');
    if (input) input.checked = true;
  }
  function getRadio(name) {
    var input = form.querySelector('input[name="' + name + '"]:checked');
    return input ? input.value : "";
  }
  function lock(name, locked) {
    var field = form.querySelector('[data-field="' + name + '"]');
    if (field) field.classList.toggle("is-locked", locked);
  }

  /* ---------- 2. keep related fields consistent ---------- */
  var ADDONS = ["OnlineSecurity", "OnlineBackup", "DeviceProtection", "TechSupport", "StreamingTV", "StreamingMovies"];

  function syncDependencies() {
    // No phone service -> "multiple lines" can only be "No phone service"
    var phone = getRadio("PhoneService");
    if (phone === "No") {
      setRadio("MultipleLines", "No phone service");
      lock("MultipleLines", true);
    } else {
      if (getRadio("MultipleLines") === "No phone service") setRadio("MultipleLines", "No");
      lock("MultipleLines", false);
    }

    // No internet -> every add-on is "No internet service"
    var internet = getRadio("InternetService");
    var noNet = internet === "No";
    ADDONS.forEach(function (name) {
      if (noNet) {
        setRadio(name, "No internet service");
      } else if (getRadio(name) === "No internet service" || getRadio(name) === "") {
        setRadio(name, "No");
      }
      lock(name, noNet);
    });
    var note = document.getElementById("addons-note");
    if (note) {
      note.textContent = noNet
        ? "These are switched off because the customer has no internet service."
        : "Switch on the extras this customer pays for.";
    }
  }

  if (form) {
    form.addEventListener("change", function (e) {
      if (e.target.name === "PhoneService" || e.target.name === "InternetService") syncDependencies();
    });
    syncDependencies();
  }

  /* ---------- 3. example customers (same two as the Assignment 1 notebook) ---------- */
  var SAMPLES = {
    risky: {
      gender: "Female", SeniorCitizen: "0", Partner: "No", Dependents: "No", tenure: "2",
      PhoneService: "Yes", MultipleLines: "No", InternetService: "Fiber optic",
      OnlineSecurity: "No", OnlineBackup: "No", DeviceProtection: "No", TechSupport: "No",
      StreamingTV: "No", StreamingMovies: "No", Contract: "Month-to-month",
      PaperlessBilling: "Yes", PaymentMethod: "Electronic check",
      MonthlyCharges: "80", TotalCharges: "160"
    },
    loyal: {
      gender: "Male", SeniorCitizen: "0", Partner: "Yes", Dependents: "Yes", tenure: "60",
      PhoneService: "Yes", MultipleLines: "Yes", InternetService: "DSL",
      OnlineSecurity: "Yes", OnlineBackup: "Yes", DeviceProtection: "Yes", TechSupport: "Yes",
      StreamingTV: "No", StreamingMovies: "No", Contract: "Two year",
      PaperlessBilling: "No", PaymentMethod: "Bank transfer (automatic)",
      MonthlyCharges: "65", TotalCharges: "3900"
    },
    clear: {
      gender: "Female", SeniorCitizen: "0", Partner: "No", Dependents: "No", tenure: "",
      PhoneService: "Yes", MultipleLines: "No", InternetService: "Fiber optic",
      OnlineSecurity: "No", OnlineBackup: "No", DeviceProtection: "No", TechSupport: "No",
      StreamingTV: "No", StreamingMovies: "No", Contract: "Month-to-month",
      PaperlessBilling: "Yes", PaymentMethod: "Electronic check",
      MonthlyCharges: "", TotalCharges: ""
    }
  };

  function fill(sample) {
    Object.keys(sample).forEach(function (key) {
      var el = form.querySelector('[name="' + key + '"]');
      if (!el) return;
      if (el.type === "radio") setRadio(key, sample[key]);
      else el.value = sample[key];
    });
    syncDependencies();
    form.querySelectorAll(".has-error").forEach(function (n) { n.classList.remove("has-error"); });
    form.querySelectorAll(".error-text").forEach(function (n) { n.remove(); });
  }

  document.querySelectorAll("[data-sample]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      fill(SAMPLES[btn.getAttribute("data-sample")]);
    });
  });
})();
