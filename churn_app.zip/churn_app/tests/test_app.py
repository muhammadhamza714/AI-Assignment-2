"""Run:  python tests/test_app.py   (from the project folder)"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, pandas as pd
import app as A

# ---- 1. every real customer: app preprocessing == notebook preprocessing ----
df = pd.read_excel(os.path.join(A.BASE_DIR, "data", "WA_Fn-UseC_-Telco-Customer-Churn.xlsx"))
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce").fillna(0)
data = df.drop(columns=["customerID"]).copy()
data["Churn"] = data["Churn"].map({"No": 0, "Yes": 1})
data["AvgMonthlySpend"] = data["TotalCharges"] / (data["tenure"] + 1)
enc = pd.get_dummies(data, drop_first=True).astype(float)
X = enc.drop("Churn", axis=1)
assert list(X.columns) == A.FEATURE_COLUMNS, "column order differs"
Xs = X.copy(); Xs[A.NUM_COLS] = A.SCALER.transform(X[A.NUM_COLS])
ref = A.MODEL.predict(Xs if A.NEEDS_SCALING else X)

mism = rejected = 0
app_pred = []
for i, r in df.iterrows():
    form = {k: str(r[k]) for k in A.CHOICES}
    form.update(tenure=str(r["tenure"]), MonthlyCharges=str(r["MonthlyCharges"]),
                TotalCharges=str(r["TotalCharges"]))
    clean, errors, _ = A.validate_form(form)
    if errors:
        rejected += 1; app_pred.append(-1); continue
    lab, _ = A.predict_customer(clean); app_pred.append(lab)
    mism += int(lab != ref[i])
print(f"Rows: {len(df)} | rejected by validation: {rejected} | prediction mismatches: {mism}")
assert rejected == 0 and mism == 0

# ---- 2. web flow with Flask test client ----
c = A.app.test_client()
base = dict(gender="Female", SeniorCitizen="0", Partner="No", Dependents="No", tenure="2",
            PhoneService="Yes", MultipleLines="No", InternetService="Fiber optic",
            OnlineSecurity="No", OnlineBackup="No", DeviceProtection="No", TechSupport="No",
            StreamingTV="No", StreamingMovies="No", Contract="Month-to-month",
            PaperlessBilling="Yes", PaymentMethod="Electronic check",
            MonthlyCharges="80", TotalCharges="160")
loyal = dict(base, gender="Male", Partner="Yes", Dependents="Yes", tenure="60", MultipleLines="Yes",
             InternetService="DSL", OnlineSecurity="Yes", OnlineBackup="Yes", DeviceProtection="Yes",
             TechSupport="Yes", Contract="Two year", PaperlessBilling="No",
             PaymentMethod="Bank transfer (automatic)", MonthlyCharges="65", TotalCharges="3900")

def post(d): return c.post("/predict", data=d)
assert c.get("/").status_code == 200
r = post(base); assert b"likely to leave" in r.data and r.status_code == 200; print("Churn case     ->", "Churn" if b"verdict-label\">Churn" in r.data else "?")
r = post(loyal); assert b"likely to stay" in r.data; print("No-churn case  -> No Churn")

# ---- 3. bad input never crashes ----
bad_cases = {
  "empty form": {},
  "missing tenure": {k: v for k, v in base.items() if k != "tenure"},
  "text tenure": dict(base, tenure="abc"),
  "negative tenure": dict(base, tenure="-4"),
  "decimal tenure": dict(base, tenure="2.5"),
  "huge monthly": dict(base, MonthlyCharges="99999"),
  "nan monthly": dict(base, MonthlyCharges="nan"),
  "inf monthly": dict(base, MonthlyCharges="inf"),
  "bad dropdown": dict(base, Contract="Lifetime"),
  "tenure 0 + total>0": dict(base, tenure="0", TotalCharges="50"),
  "script injection": dict(base, gender="<script>alert(1)</script>"),
}
for name, d in bad_cases.items():
    r = post(d)
    assert r.status_code == 400, (name, r.status_code)
    assert b"Traceback" not in r.data
    print(f"  {name:22s} -> 400 with message")
assert b"<script>alert(1)</script>" not in post(bad_cases["script injection"]).data  # escaped

# empty total -> estimated;  no-phone / no-internet auto-fixes
r = post(dict(base, TotalCharges="")); assert r.status_code == 200 and b"estimated" in r.data
r = post(dict(base, PhoneService="No", InternetService="No")); assert r.status_code == 200
assert c.get("/predict").status_code == 405 and c.get("/nope").status_code == 404
print("API:", c.post("/api/predict", json=base).get_json())
print("ALL TESTS PASSED")
