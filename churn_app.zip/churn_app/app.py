"""
Customer Churn Prediction - Flask web application
Uses the model trained in Assignment 1 (see train_model.py).

Input -> prediction flow
  1. /            shows the form (GET)
  2. /predict     receives the form (POST)
  3. validate_form()      checks every field, returns friendly error messages
  4. build_feature_row()  repeats the Assignment 1 preprocessing:
                          AvgMonthlySpend -> one-hot encoding -> same column order
                          as training -> StandardScaler on numeric columns (if needed)
  5. model.predict() / predict_proba()  -> "Churn" / "No Churn" + probability
"""
import json
import os

import joblib
import pandas as pd
from flask import Flask, jsonify, render_template, request

# Absolute paths: required so the app also works on PythonAnywhere,
# where the working directory is NOT the project folder.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)

# ----------------------------------------------------------------------------
# Load the saved artifacts ONCE when the app starts
# ----------------------------------------------------------------------------
MODEL = joblib.load(os.path.join(BASE_DIR, "model.joblib"))
SCALER = joblib.load(os.path.join(BASE_DIR, "scaler.joblib"))
with open(os.path.join(BASE_DIR, "model_meta.json")) as fh:
    META = json.load(fh)

FEATURE_COLUMNS = META["feature_columns"]   # exact training column order
NUM_COLS = META["num_cols"]
NEEDS_SCALING = META["needs_scaling"]

# ----------------------------------------------------------------------------
# Allowed values for each field (used for dropdowns AND for validation)
# ----------------------------------------------------------------------------
YES_NO = ["Yes", "No"]
CHOICES = {
    "gender": ["Female", "Male"],
    "SeniorCitizen": ["0", "1"],
    "Partner": YES_NO,
    "Dependents": YES_NO,
    "PhoneService": YES_NO,
    "MultipleLines": ["Yes", "No", "No phone service"],
    "InternetService": ["DSL", "Fiber optic", "No"],
    "OnlineSecurity": ["Yes", "No", "No internet service"],
    "OnlineBackup": ["Yes", "No", "No internet service"],
    "DeviceProtection": ["Yes", "No", "No internet service"],
    "TechSupport": ["Yes", "No", "No internet service"],
    "StreamingTV": ["Yes", "No", "No internet service"],
    "StreamingMovies": ["Yes", "No", "No internet service"],
    "Contract": ["Month-to-month", "One year", "Two year"],
    "PaperlessBilling": YES_NO,
    "PaymentMethod": ["Electronic check", "Mailed check",
                      "Bank transfer (automatic)", "Credit card (automatic)"],
}
INTERNET_ADDONS = ["OnlineSecurity", "OnlineBackup", "DeviceProtection",
                   "TechSupport", "StreamingTV", "StreamingMovies"]

# Human-readable names used in error messages
LABELS = {
    "gender": "Gender", "SeniorCitizen": "Senior citizen", "Partner": "Partner",
    "Dependents": "Dependents", "tenure": "Tenure", "PhoneService": "Phone service",
    "MultipleLines": "Multiple lines", "InternetService": "Internet service",
    "OnlineSecurity": "Online security", "OnlineBackup": "Online backup",
    "DeviceProtection": "Device protection", "TechSupport": "Tech support",
    "StreamingTV": "Streaming TV", "StreamingMovies": "Streaming movies",
    "Contract": "Contract", "PaperlessBilling": "Paperless billing",
    "PaymentMethod": "Payment method", "MonthlyCharges": "Monthly charges",
    "TotalCharges": "Total charges",
}

# Numeric limits (the training data has tenure 0-72 and monthly charges 18-119)
LIMITS = {"tenure": (0, 120), "MonthlyCharges": (0, 500), "TotalCharges": (0, 100000)}


# ----------------------------------------------------------------------------
# Validation
# ----------------------------------------------------------------------------
def validate_form(form):
    """Return (clean_values, errors, notes).

    errors : dict  field -> message   (empty dict means the input is valid)
    notes  : list  of friendly messages about values we adjusted automatically
    """
    errors, notes, clean = {}, [], {}

    # --- dropdown fields ---------------------------------------------------
    for field, allowed in CHOICES.items():
        value = (form.get(field) or "").strip()
        if not value:
            errors[field] = f"Please choose a value for {LABELS[field]}."
        elif value not in allowed:
            errors[field] = f"'{value}' is not a valid option for {LABELS[field]}."
        else:
            clean[field] = value

    # --- number fields -----------------------------------------------------
    def read_number(field, integer=False, required=True):
        raw = (form.get(field) or "").strip().replace(",", "")
        if raw == "":
            if required:
                errors[field] = f"Please enter {LABELS[field].lower()}."
            return None
        try:
            number = float(raw)
        except ValueError:
            errors[field] = f"{LABELS[field]} must be a number (you entered '{raw}')."
            return None
        if number != number or number in (float("inf"), float("-inf")):
            errors[field] = f"{LABELS[field]} must be a real number."
            return None
        low, high = LIMITS[field]
        if number < low or number > high:
            errors[field] = f"{LABELS[field]} must be between {low} and {high}."
            return None
        if integer:
            if number != int(number):
                errors[field] = f"{LABELS[field]} must be a whole number of months."
                return None
            number = int(number)
        return number

    tenure = read_number("tenure", integer=True)
    monthly = read_number("MonthlyCharges")
    total = read_number("TotalCharges", required=False)

    if tenure is not None:
        clean["tenure"] = tenure
    if monthly is not None:
        clean["MonthlyCharges"] = monthly

    # Total charges is optional: if left empty, estimate it from tenure x monthly
    if total is None and "TotalCharges" not in errors and tenure is not None and monthly is not None:
        total = round(tenure * monthly, 2)
        notes.append(f"Total charges was left empty, so it was estimated as "
                     f"tenure x monthly charges = {total:,.2f}.")
    if total is not None:
        clean["TotalCharges"] = total

    # --- consistency rules (same logic as in the dataset) -------------------
    if not errors:
        if clean["PhoneService"] == "No" and clean["MultipleLines"] != "No phone service":
            clean["MultipleLines"] = "No phone service"
            notes.append("Multiple lines was set to 'No phone service' because the customer has no phone service.")
        if clean["PhoneService"] == "Yes" and clean["MultipleLines"] == "No phone service":
            errors["MultipleLines"] = "A customer with phone service must have Yes or No for multiple lines."
        if clean["InternetService"] == "No":
            changed = False
            for f in INTERNET_ADDONS:
                if clean[f] != "No internet service":
                    clean[f] = "No internet service"
                    changed = True
            if changed:
                notes.append("Internet add-ons were set to 'No internet service' because the customer has no internet.")
        else:
            for f in INTERNET_ADDONS:
                if clean[f] == "No internet service":
                    errors[f] = f"{LABELS[f]} must be Yes or No when the customer has internet."
        if "TotalCharges" in clean and tenure == 0 and clean["TotalCharges"] > 0:
            errors["TotalCharges"] = "A customer with 0 months of tenure cannot have total charges above 0."
        if "TotalCharges" in clean and tenure and clean["TotalCharges"] < clean["MonthlyCharges"] * 0.5 and tenure >= 2:
            errors["TotalCharges"] = ("Total charges look too low for this tenure and monthly charge. "
                                      "Please check the value (or leave it empty to estimate it).")

    return clean, errors, notes


# ----------------------------------------------------------------------------
# Preprocessing + prediction  (identical steps to Assignment 1, section 7)
# ----------------------------------------------------------------------------
def build_feature_row(customer):
    row = pd.DataFrame([customer])
    row["SeniorCitizen"] = row["SeniorCitizen"].astype(int)
    row["AvgMonthlySpend"] = row["TotalCharges"] / (row["tenure"] + 1)
    row = pd.get_dummies(row)
    # Same columns, same order as training; missing dummy columns become 0
    row = row.reindex(columns=FEATURE_COLUMNS, fill_value=0).astype(float)
    if NEEDS_SCALING:
        row[NUM_COLS] = SCALER.transform(row[NUM_COLS])
    return row


def predict_customer(customer):
    row = build_feature_row(customer)
    label = int(MODEL.predict(row)[0])
    probability = float(MODEL.predict_proba(row)[0][1])
    return label, probability


def risk_level(p):
    if p < 0.35:
        return "Low", "low"
    if p < 0.6:
        return "Medium", "medium"
    return "High", "high"


def explain(c):
    """Plain-language hints, based on the patterns found in the Assignment 1 EDA."""
    up, down = [], []
    if c["Contract"] == "Month-to-month":
        up.append("Month-to-month contract: easy to cancel at any time")
    else:
        down.append(f"{c['Contract']} contract: the customer is committed for longer")
    if c["tenure"] <= 12:
        up.append(f"Short time with the company ({c['tenure']} months)")
    elif c["tenure"] >= 36:
        down.append(f"Long-time customer ({c['tenure']} months)")
    if c["InternetService"] == "Fiber optic":
        up.append("Fiber optic customers churn more often in this data")
    if c["PaymentMethod"] == "Electronic check":
        up.append("Pays by electronic check, which is linked to higher churn")
    if c["InternetService"] != "No" and c["TechSupport"] == "No":
        up.append("No tech support")
    if c["TechSupport"] == "Yes":
        down.append("Has tech support")
    if c["OnlineSecurity"] == "Yes":
        down.append("Has online security")
    return up[:4], down[:4]


def default_form():
    return {"gender": "Female", "SeniorCitizen": "0", "Partner": "No", "Dependents": "No",
            "tenure": "", "PhoneService": "Yes", "MultipleLines": "No",
            "InternetService": "Fiber optic", "OnlineSecurity": "No", "OnlineBackup": "No",
            "DeviceProtection": "No", "TechSupport": "No", "StreamingTV": "No",
            "StreamingMovies": "No", "Contract": "Month-to-month", "PaperlessBilling": "Yes",
            "PaymentMethod": "Electronic check", "MonthlyCharges": "", "TotalCharges": ""}


def render_page(values, errors=None, notes=None, result=None, status=200):
    return render_template("index.html", choices=CHOICES, values=values,
                           errors=errors or {}, notes=notes or [], result=result,
                           model_name=META["model_name"], metrics=META["metrics"]), status


# ----------------------------------------------------------------------------
# Routes
# ----------------------------------------------------------------------------
@app.route("/", methods=["GET"])
def index():
    return render_page(default_form())


@app.route("/predict", methods=["POST"])
def predict():
    values = {**default_form(), **{k: (v or "") for k, v in request.form.items()}}
    clean, errors, notes = validate_form(request.form)
    if errors:
        return render_page(values, errors=errors, notes=notes, status=400)

    try:
        label, prob = predict_customer(clean)
    except Exception:   # never show a stack trace to the user
        app.logger.exception("Prediction failed")
        return render_page(values, errors={"_form": "Something went wrong while making the prediction. Please check the values and try again."}, status=500)

    level, level_key = risk_level(prob)
    up, down = explain(clean)
    result = {
        "label": "Churn" if label == 1 else "No Churn",
        "is_churn": label == 1,
        "probability": round(prob * 100, 1),
        "level": level,
        "level_key": level_key,
        "up": up,
        "down": down,
    }
    return render_page(values, notes=notes, result=result)


@app.route("/api/predict", methods=["POST"])
def api_predict():
    """Optional JSON endpoint (handy for testing): POST the same fields as JSON."""
    payload = request.get_json(silent=True) or {}
    clean, errors, notes = validate_form({k: str(v) for k, v in payload.items()})
    if errors:
        return jsonify({"ok": False, "errors": errors}), 400
    label, prob = predict_customer(clean)
    return jsonify({"ok": True, "prediction": "Churn" if label else "No Churn",
                    "churn_probability": round(prob, 4), "notes": notes})


@app.route("/health")
def health():
    return jsonify({"status": "ok", "model": META["model_name"]})


@app.errorhandler(404)
def not_found(_):
    return render_page(default_form(), errors={"_form": "That page does not exist. You are back on the prediction form."}, status=404)


@app.errorhandler(405)
def not_allowed(_):
    return render_page(default_form(), errors={"_form": "Please use the form below to make a prediction."}, status=405)


if __name__ == "__main__":
    app.run(debug=True)
