# Deploying Churn Check on PythonAnywhere

Replace `YOUR_USERNAME` with your PythonAnywhere username everywhere below.

## 1. Run locally first
```bash
pip install -r requirements.txt
python train_model.py        # creates model.joblib, scaler.joblib, model_meta.json
python tests/test_app.py     # optional: automated checks
python app.py                # open http://127.0.0.1:5000
```

## 2. Upload the project
1. Zip the `churn_app` folder on your computer.
2. PythonAnywhere -> **Files** tab -> upload the ZIP into `/home/YOUR_USERNAME/`.
3. Open a **Bash console** (Consoles tab) and run:
   ```bash
   cd ~ && unzip churn_app.zip
   cd churn_app && ls
   ```

## 3. Packages and the model
PythonAnywhere already has Flask, pandas, numpy and scikit-learn installed.
```bash
cd ~/churn_app
pip install --user -r requirements.txt     # only installs what is missing
python train_model.py                      # rebuilds the model with THIS server's scikit-learn
```
Re-running `train_model.py` on the server is deliberate: a `.joblib` file made with one
scikit-learn version can fail to load on another. The script uses the same data, settings and
random seed as Assignment 1, so the model is identical in behaviour.

(Optional) If you prefer a virtualenv: `mkvirtualenv churnenv --python=python3.11`,
then `pip install -r requirements.txt`, and enter `/home/YOUR_USERNAME/.virtualenvs/churnenv`
in the Web tab's *Virtualenv* box.

## 4. Create the web app
1. **Web** tab -> **Add a new web app** -> *Manual configuration* -> choose the same Python
   version you used in the console (e.g. 3.11 or 3.12).
2. **Source code**: `/home/YOUR_USERNAME/churn_app`
3. **WSGI configuration file**: click the link, delete everything, paste the contents of
   `wsgi_pythonanywhere.py` (with your username), save.
4. **Static files** (optional but recommended): URL `/static/`, Directory
   `/home/YOUR_USERNAME/churn_app/static`
5. Click the green **Reload** button.

Your site is live at `https://YOUR_USERNAME.pythonanywhere.com`.

## 5. Troubleshooting
| Symptom | Fix |
|---|---|
| "Something went wrong" page | Web tab -> **Error log**; read the last lines |
| `ModuleNotFoundError` | Run `pip install --user <package>` in a Bash console, then Reload |
| `FileNotFoundError: model.joblib` | Run `python train_model.py` inside `~/churn_app` |
| Model fails to load / version warning | Re-run `python train_model.py` on the server |
| Changes not visible | Press **Reload** on the Web tab (free accounts must also reload every 3 months) |
